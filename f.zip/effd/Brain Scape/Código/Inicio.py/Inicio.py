import pygame
import json
import os
from l import Game

# Inicia Pygame
pygame.init()

# Dimensiones de la ventana
ANCHO = 800
ALTO = 600
VENTANA = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Brain Scape")

# Definir algunos colores
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
GRIS = (128, 128, 128)
AZUL = (0, 100, 255)
ROJO = (255, 0, 0)
VERDE = (0, 255, 0)

class SistemaUsuarios:
    def __init__(self):
        self.directorio_usuarios = "usuarios"
        self.crear_directorio()
        self.usuarios_registrados = self.obtener_usuarios_registrados()
    
    def crear_directorio(self):
        if not os.path.exists(self.directorio_usuarios):
            os.makedirs(self.directorio_usuarios)
    
    def obtener_usuarios_registrados(self):
        usuarios = []
        if os.path.exists(self.directorio_usuarios):
            for archivo in os.listdir(self.directorio_usuarios):
                if archivo.endswith('.json'):
                    usuarios.append(archivo[:-5])
        return usuarios
    
    def crear_json_usuario(self, nombre):
        datos_usuario = {
            "nombre": nombre,
            "id": len(self.usuarios_registrados) + 1,
            "partidas": []
        }
        
        ruta_archivo = os.path.join(self.directorio_usuarios, f"{nombre}.json")
        with open(ruta_archivo, 'w') as archivo:
            json.dump(datos_usuario, archivo, indent=4)
    
    def validar_nombre_usuario(self, nombre):
        if len(nombre) < 3 or len(nombre) > 8:
            return False, "El nombre de usuario necesita tener entre 3-8 caracteres"
        if nombre in self.usuarios_registrados:
            return False, "Nombre de usuario ya existente. Usa otro."
        return True, ""
    
    def registrar_usuario(self, nombre):
        es_valido, mensaje = self.validar_nombre_usuario(nombre)
        if es_valido:
            self.crear_json_usuario(nombre)
            self.usuarios_registrados.append(nombre)
            return True, "Nombre de usuario guardado exitosamente"
        return False, mensaje
    
    def login(self, nombre):
        if nombre in self.usuarios_registrados:
            return True, "Login exitoso"
        return False, "Usuario no registrado. Registrese para jugar"

class CampoTexto:
    
    def __init__(self, x, y, ancho, alto):
        self.rect = pygame.Rect(x, y, ancho, alto)
        self.texto = ""
        self.activo = False
        self.color_inactivo = NEGRO
        self.color_activo = AZUL
        self.color = self.color_inactivo
        self.fuente = pygame.font.Font(None, 36)

    def manejar_evento(self, evento):
        if evento.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(evento.pos):
                self.activo = True
                self.color = self.color_activo
            else:
                self.activo = False
                self.color = self.color_inactivo

        if evento.type == pygame.KEYDOWN and self.activo:
            if evento.key == pygame.K_RETURN:
                return True
            elif evento.key == pygame.K_BACKSPACE:
                self.texto = self.texto[:-1]
            elif len(self.texto) < 8:
                if evento.unicode.isalnum() or evento.unicode in '-_':
                    self.texto += evento.unicode
        return False

    def dibujar(self, superficie):
        
        pygame.draw.rect(superficie, BLANCO, self.rect)
        pygame.draw.rect(superficie, self.color, self.rect, 2)
        texto_surface = self.fuente.render(self.texto, True, NEGRO)
        superficie.blit(texto_surface, (self.rect.x + 5, self.rect.y + 5))

class Interfaz:

    def __init__(self):
        self.sistema = SistemaUsuarios()
        self.fuente = pygame.font.Font(None, 36)
        self.fuente_titulo = pygame.font.Font(None, 72)
        self.fuente_pequeña = pygame.font.Font(None, 24)
        self.mensaje = ""
        self.color_mensaje = NEGRO
        self.estado = "INICIO"
        self.campo_texto = CampoTexto(ANCHO/2 - 150, ALTO/2 - 25, 300, 50)
        self.mundo_actual = 1

        # Lista de mundos
        self.mundos = ["Mundo 1", "Mundo 2", "Mundo 3", "Mundo 4", "Mundo 5"]

        self.posicion_flecha_izq = (50, ALTO/2 - 25)
        self.posicion_flecha_der = (ANCHO - 100, ALTO/2 - 25)
        self.ultimo_click = 0

        self.imagen_inicio = pygame.image.load("bgmain/inicio2.png")  
        self.imagen_inicio = pygame.transform.scale(self.imagen_inicio, (ANCHO, ALTO))
        
        self.imagen_menu = pygame.image.load("bgmain/pantalla2.png")  
        self.imagen_menu = pygame.transform.scale(self.imagen_menu, (ANCHO, ALTO))

        self.imagen_fondo_login = pygame.image.load("bgmain/FONDO_LOGIN.png")  
        self.imagen_fondo_login = pygame.transform.scale(self.imagen_fondo_login, (ANCHO, ALTO))

        self.imagen_fondo_registro = pygame.image.load("bgmain/FONDO_REGISTRO.png") 
        self.imagen_fondo_registro = pygame.transform.scale(self.imagen_fondo_registro, (ANCHO, ALTO))

    def dibujar_boton(self, texto, x, y, ancho, alto):
        
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        color = AZUL if x < mouse[0] < x + ancho and y < mouse[1] < y + alto else GRIS
        pygame.draw.rect(VENTANA, color, (x, y, ancho, alto))
        texto_surface = self.fuente.render(texto, True, BLANCO)
        texto_rect = texto_surface.get_rect(center=(x + ancho/2, y + alto/2))
        VENTANA.blit(texto_surface, texto_rect)
        
        if x < mouse[0] < x + ancho and y < mouse[1] < y + alto and click[0]:
            tiempo_actual = pygame.time.get_ticks()
            if tiempo_actual - self.ultimo_click > 200:
                self.ultimo_click = tiempo_actual
                return True
        return False

    def dibujar_flecha(self, superficie, es_derecha, x, y):
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        
        rect = pygame.Rect(x, y, 50, 50)
        color = AZUL if rect.collidepoint(mouse) else GRIS
        
        if es_derecha:
            pygame.draw.polygon(superficie, color, [(x+10, y+25), (x+40, y+25), (x+25, y+10), (x+40, y+25), (x+25, y+40)])
        else:
            pygame.draw.polygon(superficie, color, [(x+40, y+25), (x+10, y+25), (x+25, y+10), (x+10, y+25), (x+25, y+40)])


        if rect.collidepoint(mouse) and click[0]:
            tiempo_actual = pygame.time.get_ticks()
            if tiempo_actual - self.ultimo_click > 200:
                self.ultimo_click = tiempo_actual
                return True
        return False
    
    def cambiar_mundo(self, direccion):
        nuevo_mundo = self.mundo_actual + direccion
        if 1 <= nuevo_mundo <= len(self.mundos):
            self.mundo_actual = nuevo_mundo
            return True
        return False

    def dibujar_mensaje(self):
        if self.mensaje:
            texto_surface = self.fuente_pequeña.render(self.mensaje, True, self.color_mensaje)
            VENTANA.blit(texto_surface, (ANCHO/2 - texto_surface.get_width()/2, ALTO - 100))

    def mostrar_inicio(self):
        VENTANA.fill(BLANCO)
        VENTANA.blit(self.imagen_inicio, (0, 0))
        
        if self.dibujar_boton("JUGAR", ANCHO/2 - 100, ALTO/2 + 50, 200, 50):
            self.estado = "MENU"
            self.mensaje = ""
            print("Hola")

    def mostrar_menu_principal(self):
        VENTANA.blit(self.imagen_menu, (0, 0))
        
        if self.dibujar_boton("Registro", ANCHO/2 - 100, ALTO/2 - 30, 200, 50):
            self.estado = "REGISTRO"
            self.campo_texto.texto = ""
            self.mensaje = ""
            
        if self.dibujar_boton("Login", ANCHO/2 - 100, ALTO/2 + 40, 200, 50):
            self.estado = "LOGIN"
            self.campo_texto.texto = ""
            self.mensaje = ""

    def mostrar_registro(self):
        VENTANA.blit(self.imagen_fondo_registro, (0, 0))  
        if self.dibujar_boton("Volver", 20, 20, 100, 40):
            self.estado = "MENU"
            self.mensaje = ""

        self.campo_texto.dibujar(VENTANA)
        self.dibujar_mensaje()

    def mostrar_login(self):
        VENTANA.blit(self.imagen_fondo_login, (0, 0))
        if self.dibujar_boton("Volver", 20, 20, 100, 40):
            self.estado = "MENU"
            self.mensaje = ""
        
        self.campo_texto.dibujar(VENTANA)
        self.dibujar_mensaje()

    def mostrar_mundo(self, numero):
        VENTANA.blit(self.imagen_menu, (0, 0))
        
        if self.dibujar_boton("Jugar", ANCHO / 2 - 100, 300, 200, 50):
            print("HI")
            # Crear una instancia de la clase Game
            juego = Game()

            # Llamar al método run con esa instancia
            juego.run()


    def mostrar_mundos(self):
        self.mostrar_mundo(self.mundo_actual)

    def ejecutar(self):
        
        reloj = pygame.time.Clock()
        corriendo = True
        
        while corriendo:
            
            for evento in pygame.event.get():
                
                if evento.type == pygame.QUIT:
                    corriendo = False
                
                if self.estado in ["REGISTRO", "LOGIN"]:
                    
                    if self.campo_texto.manejar_evento(evento):
                        if self.estado == "REGISTRO":
                            exito, mensaje = self.sistema.registrar_usuario(self.campo_texto.texto)
                            self.mensaje = mensaje
                            self.color_mensaje = VERDE if exito else ROJO
                        elif self.estado == "LOGIN":
                            exito, mensaje = self.sistema.login(self.campo_texto.texto)
                            if exito:
                                self.estado = "MUNDOS"
                                self.mundo_actual = 1
                            else:
                                self.mensaje = mensaje
                                self.color_mensaje = ROJO
            
            if self.estado == "INICIO":
                self.mostrar_inicio()
            elif self.estado == "MENU":
                self.mostrar_menu_principal()
            elif self.estado == "REGISTRO":
                self.mostrar_registro()
            elif self.estado == "LOGIN":
                self.mostrar_login()
            elif self.estado == "MUNDOS":
                self.mostrar_mundos()
            pygame.display.flip()
            reloj.tick(60)

        pygame.quit()

if __name__ == "__main__":
    interfaz = Interfaz()
    interfaz.ejecutar()
