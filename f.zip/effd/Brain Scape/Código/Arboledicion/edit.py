import tkinter as tk
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import json
import random
from typing import List, Optional, Dict
from datetime import datetime

class NodoPregunta:
    def __init__(self, pregunta: str, peso: float = 1.0, categoria: str = ""):
        self.pregunta = pregunta
        self.peso = peso
        self.correctas = 0
        self.incorrectas = 0
        self.izquierdo = None
        self.derecho = None
        self.categoria = categoria

class ArbolTrivia:
    def __init__(self):
        self.raiz = None
        self.archivo_historial = "historial_trivia.json"
        self.archivo_partidas = "partidas_trivia.json"
        self.preguntas_trivia = [
            {"pregunta": "¿Cuál es la capital de Francia?", "respuesta": "París", "opciones": ["Londres", "París", "Madrid", "Berlín"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Geografía"},
            {"pregunta": "¿En qué año comenzó la Segunda Guerra Mundial?", "respuesta": "1939", "opciones": ["1939", "1940", "1941", "1938"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Historia"},
            {"pregunta": "¿Quién pintó La Mona Lisa?", "respuesta": "Leonardo da Vinci", "opciones": ["Pablo Picasso", "Vincent van Gogh", "Leonardo da Vinci", "Miguel Ángel"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Arte"},
            {"pregunta": "¿Cuál es el elemento químico más abundante en el universo?", "respuesta": "Hidrógeno", "opciones": ["Helio", "Hidrógeno", "Oxígeno", "Carbono"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Ciencia"},
            {"pregunta": "¿Cuál es el planeta más grande del sistema solar?", "respuesta": "Júpiter", "opciones": ["Saturno", "Júpiter", "Neptuno", "Urano"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Astronomía"},
            {"pregunta": "¿En qué año se fundó Microsoft?", "respuesta": "1975", "opciones": ["1975", "1976", "1974", "1977"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Tecnología"},
            {"pregunta": "¿Quién escribió 'Cien años de soledad'?", "respuesta": "Gabriel García Márquez", "opciones": ["Mario Vargas Llosa", "Gabriel García Márquez", "Jorge Luis Borges", "Pablo Neruda"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Literatura"},
            {"pregunta": "¿Cuál es el río más largo del mundo?", "respuesta": "Nilo", "opciones": ["Amazonas", "Nilo", "Yangtsé", "Misisipi"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Geografía"},
            {"pregunta": "¿En qué año llegó el hombre a la Luna?", "respuesta": "1969", "opciones": ["1969", "1970", "1968", "1971"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Historia"},
            {"pregunta": "¿Cuál es la capital de Japón?", "respuesta": "Tokio", "opciones": ["Seúl", "Pekín", "Tokio", "Bangkok"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Geografía"},
            {"pregunta": "¿Quién descubrió la penicilina?", "respuesta": "Alexander Fleming", "opciones": ["Alexander Fleming", "Louis Pasteur", "Marie Curie", "Robert Koch"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Ciencia"},
            {"pregunta": "¿Cuál es el país más poblado del mundo?", "respuesta": "India", "opciones": ["India", "China", "Estados Unidos", "Indonesia"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Geografía"},
            {"pregunta": "¿En qué año se fundó Google?", "respuesta": "1998", "opciones": ["1998", "1999", "1997", "2000"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Tecnología"},
            {"pregunta": "¿Cuál es el océano más grande?", "respuesta": "Pacífico", "opciones": ["Atlántico", "Índico", "Pacífico", "Ártico"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Geografía"},
            {"pregunta": "¿Quién escribió 'Romeo y Julieta'?", "respuesta": "William Shakespeare", "opciones": ["William Shakespeare", "Miguel de Cervantes", "Charles Dickens", "Jane Austen"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Literatura"},
            {"pregunta": "¿Cuál es el elemento más pesado de la tabla periódica?", "respuesta": "Oganesón", "opciones": ["Uranio", "Plutonio", "Oganesón", "Fermio"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Ciencia"},
            {"pregunta": "¿En qué año cayó el Muro de Berlín?", "respuesta": "1989", "opciones": ["1989", "1990", "1988", "1991"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Historia"},
            {"pregunta": "¿Quién pintó 'La noche estrellada'?", "respuesta": "Vincent van Gogh", "opciones": ["Claude Monet", "Vincent van Gogh", "Salvador Dalí", "Pablo Picasso"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Arte"},
            {"pregunta": "¿Cuál es la montaña más alta del mundo?", "respuesta": "Monte Everest", "opciones": ["Monte Everest", "K2", "Kanchenjunga", "Lhotse"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Geografía"},
            {"pregunta": "¿En qué año se inventó Internet?", "respuesta": "1969", "opciones": ["1969", "1970", "1968", "1971"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Tecnología"},
            {"pregunta": "¿Quién fue el primer presidente de Estados Unidos?", "respuesta": "George Washington", "opciones": ["Thomas Jefferson", "John Adams", "George Washington", "Benjamin Franklin"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Historia"},
            {"pregunta": "¿Cuál es el metal más precioso?", "respuesta": "Rodio", "opciones": ["Oro", "Platino", "Rodio", "Paladio"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Ciencia"},
            {"pregunta": "¿Quién escribió 'El Quijote'?", "respuesta": "Miguel de Cervantes", "opciones": ["Miguel de Cervantes", "Federico García Lorca", "Gabriel García Márquez", "Pablo Neruda"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Literatura"},
            {"pregunta": "¿Cuál es la capital de Australia?", "respuesta": "Canberra", "opciones": ["Sídney", "Melbourne", "Canberra", "Brisbane"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Geografía"},
            {"pregunta": "¿En qué año se fundó Facebook?", "respuesta": "2004", "opciones": ["2004", "2005", "2003", "2006"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Tecnología"},
            {"pregunta": "¿Quién pintó 'El grito'?", "respuesta": "Edvard Munch", "opciones": ["Vincent van Gogh", "Edvard Munch", "Pablo Picasso", "Salvador Dalí"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Arte"},
            {"pregunta": "¿Cuál es el país más grande del mundo?", "respuesta": "Rusia", "opciones": ["China", "Estados Unidos", "Rusia", "Canadá"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Geografía"},
            {"pregunta": "¿En qué año terminó la Primera Guerra Mundial?", "respuesta": "1918", "opciones": ["1918", "1919", "1917", "1920"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Historia"},
            {"pregunta": "¿Quién descubrió la radioactividad?", "respuesta": "Henri Becquerel", "opciones": ["Marie Curie", "Henri Becquerel", "Wilhelm Röntgen", "Ernest Rutherford"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Ciencia"},
            {"pregunta": "¿Cuál es el idioma más hablado del mundo?", "respuesta": "Chino mandarín", "opciones": ["Inglés", "Español", "Chino mandarín", "Hindi"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Cultura"},
            {"pregunta": "¿Quién escribió '1984'?", "respuesta": "George Orwell", "opciones": ["Aldous Huxley", "George Orwell", "Ray Bradbury", "H.G. Wells"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Literatura"},
            {"pregunta": "¿Cuál es el planeta más cercano al Sol?", "respuesta": "Mercurio", "opciones": ["Venus", "Mercurio", "Marte", "Tierra"], "peso": 1.0, "correctas": 0, "incorrectas": 0, "categoria": "Astronomía"}
        ]
        self.partidas = self.cargar_partidas()
        self.puntaje_actual = 0

    def cargar_partidas(self) -> Dict:
        try:
            with open(self.archivo_partidas, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {
                "ultima_partida": 0,
                "partidas": []
            }

    def guardar_partidas(self) -> None:
        with open(self.archivo_partidas, 'w', encoding='utf-8') as f:
            json.dump(self.partidas, f, ensure_ascii=False, indent=2)

    def registrar_partida(self, nombre_partida: str = None) -> None:
        if nombre_partida is None or nombre_partida.strip() == "":
            nombre_partida = f"Partida_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        self.partidas["ultima_partida"] += 1
        numero_partida = self.partidas["ultima_partida"]
        
        historial_actual = self._obtener_historial_recursivo(self.raiz)
        
        nueva_partida = {
            "numero_partida": numero_partida,
            "nombre_partida": nombre_partida,
            "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "puntaje": self.puntaje_actual,
            "arbol": historial_actual
        }
        
        self.partidas["partidas"].append(nueva_partida)
        self.guardar_partidas()

    def iniciar_nueva_partida(self) -> None:
        self.puntaje_actual = 0
        self.construir_arbol(self.preguntas_trivia)

    def actualizar_historial(self, pregunta: NodoPregunta, correcta: bool) -> None:
        if correcta:
            pregunta.correctas += 1
            pregunta.peso *= 0.9
            self.puntaje_actual += 2
        else:
            pregunta.incorrectas += 1
            pregunta.peso *= 1.1

        self.puntaje_actual = max(0, self.puntaje_actual)

    def construir_arbol(self, preguntas: List[dict]) -> None:
        preguntas_ordenadas = sorted(preguntas, key=lambda x: x['peso'])
        self.raiz = self._construir_recursivo(preguntas_ordenadas, 0, len(preguntas_ordenadas) - 1)

    def _construir_recursivo(self, preguntas: List[dict], inicio: int, fin: int) -> Optional[NodoPregunta]:
        if inicio > fin:
            return None
        medio = (inicio + fin) // 2
        pregunta_actual = preguntas[medio]
        nodo = NodoPregunta(
            pregunta=pregunta_actual['pregunta'], 
            peso=pregunta_actual['peso'],
            categoria=pregunta_actual.get('categoria', '')
            )
        nodo.correctas = pregunta_actual.get('correctas', 0)
        nodo.incorrectas = pregunta_actual.get('incorrectas', 0)
        nodo.izquierdo = self._construir_recursivo(preguntas, inicio, medio - 1)
        nodo.derecho = self._construir_recursivo(preguntas, medio + 1, fin)
        return nodo

    def _obtener_historial_recursivo(self, nodo: NodoPregunta) -> dict:
        if not nodo:
            return {}
        
        def obtener_preguntas_nivel(nodo: NodoPregunta, nivel: int, nivel_objetivo: int) -> List[dict]:
            if not nodo:
                return []
            if nivel == nivel_objetivo:
                pregunta_info = next((p for p in self.preguntas_trivia if p["pregunta"] == nodo.pregunta), None)
                return [{
                    'pregunta': nodo.pregunta,
                    'peso': nodo.peso,
                    'correctas': nodo.correctas,
                    'incorrectas': nodo.incorrectas,
                    'categoria': pregunta_info['categoria'] if pregunta_info else nodo.categoria,
                    'respuesta': pregunta_info['respuesta'] if pregunta_info else '',
                    'opciones': pregunta_info['opciones'] if pregunta_info else []
                }]
            
            preguntas = []
            preguntas.extend(obtener_preguntas_nivel(nodo.izquierdo, nivel + 1, nivel_objetivo))
            preguntas.extend(obtener_preguntas_nivel(nodo.derecho, nivel + 1, nivel_objetivo))
            return preguntas

        historial = {
            "nivel1": obtener_preguntas_nivel(nodo, 0, 0),
            "nivel2": obtener_preguntas_nivel(nodo, 0, 1),
            "nivel3": obtener_preguntas_nivel(nodo, 0, 2),
            "nivel4": obtener_preguntas_nivel(nodo, 0, 3),
            "nivel5": obtener_preguntas_nivel(nodo, 0, 4)
        }
        
        return historial

    def guardar_historial(self) -> None:
        historial = self._obtener_historial_recursivo(self.raiz)
        with open(self.archivo_historial, 'w', encoding='utf-8') as f:
            json.dump(historial, f, ensure_ascii=False, indent=2)

    def cargar_historial(self) -> None:
        try:
            with open(self.archivo_historial, 'r', encoding='utf-8') as f:
                historial = json.load(f)
                
                preguntas = []
                for nivel in ["nivel1", "nivel2", "nivel3", "nivel4", "nivel5"]:
                    if nivel in historial:
                        preguntas.extend(historial[nivel])
                
                self.construir_arbol(preguntas)
        except FileNotFoundError:
            print("No se encontró archivo de historial. Se iniciará con un nuevo árbol.")
            self.construir_arbol(self.preguntas_trivia)

    def seleccionar_preguntas_partida(self, cantidad: int = 5) -> List[NodoPregunta]:
        preguntas_seleccionadas = []
        niveles_visitados = set()
        if self.raiz:
            preguntas_seleccionadas.append(self.raiz)
            niveles_visitados.add(0)

        def obtener_preguntas_nivel(nodo: NodoPregunta, nivel_actual: int, nivel_objetivo: int) -> List[NodoPregunta]:
            if not nodo:
                return []
            if nivel_actual == nivel_objetivo:
                return [nodo]
            preguntas = []
            preguntas.extend(obtener_preguntas_nivel(nodo.izquierdo, nivel_actual + 1, nivel_objetivo))
            preguntas.extend(obtener_preguntas_nivel(nodo.derecho, nivel_actual + 1, nivel_objetivo))
            return preguntas

        while len(preguntas_seleccionadas) < cantidad:
            nivel = random.randint(1, 4)
            if nivel not in niveles_visitados:
                preguntas_nivel = obtener_preguntas_nivel(self.raiz, 0, nivel)
                if preguntas_nivel:
                    pregunta_seleccionada = random.choice(preguntas_nivel)
                    preguntas_seleccionadas.append(pregunta_seleccionada)
                    niveles_visitados.add(nivel)

        return preguntas_seleccionadas

    def obtener_info_pregunta(self, pregunta_nodo: NodoPregunta) -> dict:
        return next(p for p in self.preguntas_trivia if p["pregunta"] == pregunta_nodo.pregunta)
    
class TriviaGUI:
    def __init__(self, root, trivia):
        self.root = root
        self.root.title("Juego de Trivia")
        self.root.geometry("800x600")
        self.root.configure(bg='#f0f0f0')
        
        self.trivia = trivia
        self.preguntas_actuales = []
        self.pregunta_actual_index = 0
        self.botones_respuesta = []
        self.current_view = "juego"
        
        self.center_window()
        self.setup_gui()
        
    def center_window(self):
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'+{x}+{y}')
        
    def setup_gui(self):
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.place(relx=0.5, rely=0.5, anchor="center")
        
        if self.current_view == "juego":
            self.iniciar_nueva_partida()
        elif self.current_view == "historial":
            self.mostrar_historial()
        elif self.current_view == "final":
            self.finalizar_partida()
        
    def iniciar_nueva_partida(self):
        self.current_view = "juego"
        self.trivia.iniciar_nueva_partida()
        self.preguntas_actuales = self.trivia.seleccionar_preguntas_partida()
        self.pregunta_actual_index = 0
        self.mostrar_trivia_boton()
        
    def mostrar_trivia_boton(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()
            
        if self.pregunta_actual_index >= len(self.preguntas_actuales):
            self.finalizar_partida()
            return
            
        trivia_button = ttk.Button(
            self.main_frame,
            text=f"Trivia {self.pregunta_actual_index + 1}/{len(self.preguntas_actuales)}",
            command=self.mostrar_pregunta,
            width=40
        )
        trivia_button.pack(pady=20)
        
    def mostrar_pregunta(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()
            
        pregunta_nodo = self.preguntas_actuales[self.pregunta_actual_index]
        info_pregunta = self.trivia.obtener_info_pregunta(pregunta_nodo)
        
        # Frame principal
        principal_frame = ttk.Frame(self.main_frame)
        principal_frame.pack(expand=True, fill="both")
        
        # Frame superior para datos
        datos_frame = ttk.Frame(principal_frame)
        datos_frame.pack(side="top", fill="x", pady=10)
        
        # Contador de preguntas
        ttk.Label(
            datos_frame,
            text=f"Pregunta {self.pregunta_actual_index + 1}/{len(self.preguntas_actuales)}",
            font=('Helvetica', 12)
        ).pack(side="left", padx=10)
        
        # Categoría
        ttk.Label(
            datos_frame,
            text=f"Categoría: {info_pregunta['categoria']}",
            font=('Helvetica', 12)
        ).pack(side="left", padx=10)
        
        # Puntaje
        ttk.Label(
            datos_frame,
            text=f"Puntaje: {self.trivia.puntaje_actual}",
            font=('Helvetica', 12)
        ).pack(side="left", padx=10)
        
        # Frame central para la pregunta
        pregunta_frame = ttk.Frame(principal_frame)
        pregunta_frame.pack(expand=True, fill="both")
        
        # Pregunta
        pregunta_label = ttk.Label(
            pregunta_frame,
            text=info_pregunta['pregunta'],
            font=('Helvetica', 14, 'bold'),
            wraplength=600
        )
        pregunta_label.pack(pady=20)
        
        # Botones de respuesta
        self.botones_respuesta = []
        opciones = info_pregunta['opciones'].copy()
        random.shuffle(opciones)
        
        respuestas_frame = ttk.Frame(pregunta_frame)
        respuestas_frame.pack(expand=True, fill="both")
        
        for opcion in opciones:
            btn = ttk.Button(
                respuestas_frame,
                text=opcion,
                command=lambda o=opcion: self.verificar_respuesta(o, info_pregunta['respuesta']),
                width=40
            )
            btn.pack(pady=5)
            self.botones_respuesta.append(btn)
            
    def verificar_respuesta(self, respuesta_seleccionada, respuesta_correcta):
        pregunta_nodo = self.preguntas_actuales[self.pregunta_actual_index]
        es_correcta = respuesta_seleccionada == respuesta_correcta
        
        for btn in self.botones_respuesta:
            btn['state'] = 'disabled'
        
        self.trivia.actualizar_historial(pregunta_nodo, es_correcta)
        
        if es_correcta:
            messagebox.showinfo("¡Correcto!", "¡Has acertado! +2 puntos")
        else:
            messagebox.showinfo("Incorrecto", f"La respuesta correcta era: {respuesta_correcta}")
        
        self.pregunta_actual_index += 1
        
        if self.pregunta_actual_index >= len(self.preguntas_actuales):
            self.finalizar_partida()
        else:
            self.mostrar_trivia_boton()
        
    def finalizar_partida(self):
        self.current_view = "final"
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        final_frame = ttk.Frame(self.main_frame)
        final_frame.pack(expand=True, fill="both")

        ttk.Label(
            final_frame,
            text="¡Partida Finalizada!",
            font=('Helvetica', 20, 'bold')
        ).pack(pady=20)

        ttk.Label(
            final_frame,
            text=f"Puntaje Final: {self.trivia.puntaje_actual}",
            font=('Helvetica', 16)
        ).pack(pady=10)

        button_frame = ttk.Frame(final_frame)
        button_frame.pack(pady=20)

        ttk.Button(
            button_frame,
            text="Guardar Partida",
            command=self.guardar_partida
        ).pack(side="left", padx=10)

        ttk.Button(
            button_frame,
            text="Historial",
            command=self.mostrar_historial
        ).pack(side="left", padx=10)

        ttk.Button(
            button_frame,
            text="Nueva Partida",
            command=self.iniciar_nueva_partida
        ).pack(side="left", padx=10)

        ttk.Button(
            button_frame,
            text="Salir",
            command=self.root.destroy
        ).pack(side="left", padx=10)

    def mostrar_historial(self):
        self.current_view = "historial"
        for widget in self.main_frame.winfo_children():
            widget.destroy()
            
        historial_frame = ttk.Frame(self.main_frame)
        historial_frame.pack(expand=True, fill="both")
            
        ttk.Label(
            historial_frame,
            text="Historial de Partidas",
            font=('Helvetica', 20, 'bold')
        ).pack(pady=20)
        
        # Frame para el Treeview y scrollbar
        tree_frame = ttk.Frame(historial_frame)
        tree_frame.pack(expand=True, fill="both", padx=10)
        
        tree = ttk.Treeview(tree_frame, columns=("Fecha", "Nombre", "Puntaje"), show="headings")
        tree.heading("Fecha", text="Fecha")
        tree.heading("Nombre", text="Nombre")
        tree.heading("Puntaje", text="Puntaje")
        
        tree.pack(side="left", expand=True, fill="both")
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scrollbar.set)
        
        for partida in self.trivia.partidas["partidas"]:
            tree.insert("", "end", values=(
                partida["fecha"],
                partida["nombre_partida"],
                partida["puntaje"]
            ))
        
        ttk.Button(
            historial_frame,
            text="Volver",
            command=self.finalizar_partida
        ).pack(pady=20)

    def guardar_partida(self):
        nombre_partida = simpledialog.askstring("Guardar Partida", "Ingresa el nombre de la partida (o presiona Enter para guardarlo automáticamente):")
        if nombre_partida is not None:
            self.trivia.registrar_partida(nombre_partida)
        self.finalizar_partida()

if __name__ == "__main__":
    root = tk.Tk()
    trivia = ArbolTrivia()
    app = TriviaGUI(root, trivia)
    root.mainloop()