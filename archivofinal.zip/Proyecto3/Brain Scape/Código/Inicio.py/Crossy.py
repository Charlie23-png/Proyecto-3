import pygame
import random
import sys
import tkinter as tk
from tkinter import messagebox, simpledialog

from Arbol import ArbolTrivia, NodoPregunta

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

PLAYER_SIZE = 40
OBJECT_WIDTH = 60
OBJECT_HEIGHT = 40
MOVEMENT_SPEED = 5
OBJECT_SPEED = 3

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

WORLDS = {
    "City of Stars": {
        "background": (50, 50, 70),
        #"background_image": r"bgmain\JPG\FONDOCIUDAD.png",  
        "objects": ["car", "bus", "taxi", "truck", "motorcycle"],
        "object_colors": [BLUE, BLUE, BLUE, BLUE, BLUE]
    },
    "Cowboys": {
        "background": (139, 69, 19),
        #"background_image": r"bgmain\JPG\FONDOTEXAS.png",  
        "objects": ["horse", "wagon", "tumbleweed", "cattle", "stagecoach"],
        "object_colors": [BLUE, BLUE, BLUE, BLUE, BLUE]
    },
    "Fairy Forest": {
        "background": (34, 139, 34),
        #"background_image": r"bgmain\JPG\FONDOBOSQUE.png",  
        "objects": ["fairy", "unicorn", "dragon", "elf", "pixie"],
        "object_colors": [BLUE, BLUE, BLUE, BLUE, BLUE]
    },
    "The end of the rawr": {
        "background": (169, 169, 169),
        #"background_image": r"bgmain\JPG\FONDOESPACIO.png", 
        "objects": ["t-rex", "raptor", "pterodactyl", "triceratops", "stegosaurus"],
        "object_colors": [BLUE, BLUE, BLUE, BLUE, BLUE]
    },
    "Santa Teresa Beach": {
        "background": (135, 206, 235),
        #"background_image": r"bgmain\JPG\FONDOARENA.png",  
        "objects": ["surfboard", "boat", "seagull", "dolphin", "wave"],
        "object_colors": [BLUE, BLUE, BLUE, BLUE, BLUE]
    }
}


class Player:
    """
    Representa al jugador en el juego, controla su movimiento, su estado y su puntuación.
    """
    def __init__(self):
        """
        Inicializa el jugador con su posición, imagen, puntuación y estado de vida.
        """
        self.rect = pygame.Rect(WINDOW_WIDTH // 2, WINDOW_HEIGHT - PLAYER_SIZE - 10, PLAYER_SIZE, PLAYER_SIZE)
        self.image = pygame.image.load(r"bgmain\conejin.png")  
        self.image = pygame.transform.scale(self.image, (PLAYER_SIZE, PLAYER_SIZE))  
        self.score = 0
        self.is_alive = True

    def move(self, dx, dy):
        """
        Mueve al jugador según las teclas presionadas.
        
        Args:
        dx (int): Desplazamiento horizontal.
        dy (int): Desplazamiento vertical.
        """
        new_rect = self.rect.move(dx * MOVEMENT_SPEED, dy * MOVEMENT_SPEED)
        if 0 <= new_rect.x <= WINDOW_WIDTH - PLAYER_SIZE and 0 <= new_rect.y <= WINDOW_HEIGHT - PLAYER_SIZE:
            self.rect = new_rect

    def draw(self, screen):
        """
        Dibuja al jugador en la pantalla usando su imagen.
        
        Args:
        screen (pygame.Surface): La superficie donde se dibuja el jugador.
        """
        screen.blit(self.image, self.rect.topleft)


class MovingObject:
    """
    Representa un objeto en movimiento en el juego.
    """
    def __init__(self, y_pos: int, x_pos: int, direction: int, color, object_type: str, speed: float):
        """
        Inicializa el objeto en movimiento.
        
        Args:
        y_pos (int): Posición vertical inicial.
        x_pos (int): Posición horizontal inicial.
        direction (int): Dirección en la que se mueve el objeto.
        color (tuple): Color del objeto.
        object_type (str): Tipo de objeto (ej. "car", "bus").
        speed (float): Velocidad del objeto.
        """
        self.direction = direction
        self.rect = pygame.Rect(x_pos, y_pos, OBJECT_WIDTH, OBJECT_HEIGHT)
        self.color = color
        self.object_type = object_type
        self.speed = speed

    def move(self):
        """
        Mueve el objeto en la dirección indicada. Si el objeto se sale de la pantalla, reaparece en el lado opuesto.
        """
        self.rect.x += self.direction * self.speed
        if self.direction > 0 and self.rect.left > WINDOW_WIDTH:
            self.rect.right = 0
        elif self.direction < 0 and self.rect.right < 0:
            self.rect.left = WINDOW_WIDTH

    def draw(self, screen):
        """
        Dibuja el objeto en la pantalla.
        
        Args:
        screen (pygame.Surface): La superficie donde se dibuja el objeto.
        """
        pygame.draw.rect(screen, self.color, self.rect)
        if "car" in self.object_type.lower() or "bus" in self.object_type.lower():
            pygame.draw.circle(screen, BLACK, (self.rect.x + 10, self.rect.bottom), 5)
            pygame.draw.circle(screen, BLACK, (self.rect.right - 10, self.rect.bottom), 5)

class CrossyRoadTrivia:
    def __init__(self):
        """
        Inicializa la instancia de CrossyRoadTrivia, configurando la pantalla del juego,
        las preguntas de trivia, el jugador y el orden de los niveles. 
        """
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Crossy Road Trivia")
        
        self.trivia = ArbolTrivia()
        self.trivia.iniciar_nueva_partida()
        
        self.clock = pygame.time.Clock()
        self.player = Player()
        self.current_level = 0
        self.world_order = list(WORLDS.keys())
        random.shuffle(self.world_order)
        self.moving_objects = []
        self.game_state = "trivia"
        
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        self.large_font = pygame.font.Font(None, 48)
        
        self.preguntas_correctas = 0
        self.niveles_sin_dificultad = 0
        self.niveles_con_dificultad = 0
        self.total_score = 0
        
        self.preguntas_actuales = self.trivia.seleccionar_preguntas_partida()
        self.pregunta_actual_index = 0
        self.trivia_respondida = False
        self.dificultad_nivel = 1

    def mostrar_historial_partidas(self):
        """
        Muestra el historial de partidas ordenado por puntaje y nombre en la pantalla.
        Permite al jugador ver el top 10 de puntajes y regresar al menú principal.
        """
        self.screen.fill((50, 50, 70))  # Fondo oscuro
        
        # Título
        titulo = self.large_font.render("Historial de Partidas", True, WHITE)
        titulo_rect = titulo.get_rect(center=(WINDOW_WIDTH // 2, 50))
        self.screen.blit(titulo, titulo_rect)
        
        # Obtener historial ordenado
        historial = self.trivia.obtener_historial_partidas()
        # Ordenar primero por puntaje (descendente) y luego por nombre (ascendente) si hay empate
        historial.sort(key=lambda x: (-x[1], x[0]))
        
        y_pos = 120
        for i, (nombre, puntaje) in enumerate(historial[:10]):  # Mostrar top 10
            # Formatear texto con padding para alinear
            texto = f"{i+1}. {nombre:<20} {puntaje:>10.1f} pts"
            partida_texto = self.font.render(texto, True, WHITE)
            partida_rect = partida_texto.get_rect(center=(WINDOW_WIDTH // 2, y_pos))
            self.screen.blit(partida_texto, partida_rect)
            y_pos += 40
            
        # Botón de volver
        volver_texto = self.font.render("Presiona ESPACIO para volver", True, WHITE)
        volver_rect = volver_texto.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT - 50))
        self.screen.blit(volver_texto, volver_rect)
        
        pygame.display.flip()
        
        # Esperar input
        esperando = True
        while esperando:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        esperando = False
                        return self.mostrar_menu_final()

    def crear_nivel(self, world_theme, dificultad=1):
        """
        Crea el nivel actual generando objetos en movimiento según el tema del mundo 
        y la dificultad seleccionada.
        
        Args:
            world_theme: Tema del mundo actual.
            dificultad: Nivel de dificultad para determinar la cantidad y velocidad 
                        de los objetos en movimiento (por defecto 1).
        """
        self.moving_objects = []
        theme = WORLDS[world_theme]
        y_positions = [100, 200, 300, 400, 500]

        # Determinar número de objetos base por fila
        if dificultad == 1:
            objetos_por_fila = 3  # 3 objetos por fila para dificultad 1
        else:
            objetos_por_fila = random.choice([4, 5])  # 4 o 5 objetos por fila para dificultad 2

        num_objetos = min(objetos_por_fila * len(y_positions), 20)  # Limitar a 20 objetos máximo

        for fila, y_pos in enumerate(y_positions):
            # Determinar dirección alternante para los objetos de la fila
            direcciones = [random.choice([1, -1]) for _ in range(objetos_por_fila)]

            for i in range(objetos_por_fila):
                color = theme["object_colors"][i % len(theme["object_colors"])]
                object_type = theme["objects"][i % len(theme["objects"])]

                spacing = WINDOW_WIDTH // (objetos_por_fila + 1)

                # Incrementar velocidad según dificultad
                velocidad_base = OBJECT_SPEED + (dificultad - 1) * 1.0  # Incremento base por dificultad
                if dificultad == 1:
                    velocidad_base += 1.0  # Velocidad adicional para dificultad 1
                elif dificultad == 2:
                    velocidad_base += 2.0  # Velocidad adicional para dificultad 2

                # Calcular posición inicial del objeto basado en su dirección
                direccion_fila = direcciones[i]  # Obtener la dirección del objeto
                if direccion_fila > 0:  # Movimiento de izquierda a derecha
                    x_pos = -OBJECT_WIDTH + (i * spacing)
                else:  # Movimiento de derecha a izquierda
                    x_pos = WINDOW_WIDTH + (i * spacing)

                # Crear el objeto en movimiento
                objeto = MovingObject(
                    y_pos=y_pos,
                    x_pos=x_pos,
                    direction=direccion_fila,
                    color=color,
                    object_type=object_type,
                    speed=velocidad_base + random.uniform(-0.5, 0.5)
                )

                self.moving_objects.append(objeto)

    def lanzar_trivia_tkinter(self, dificultad=1):
        """
        Lanza la trivia de la partida actual usando la librería tkinter para mostrar 
        las preguntas y opciones al jugador.
        
        Args:
            dificultad: Dificultad actual del juego.
        
        Returns:
            Tuple: Un valor booleano indicando si la trivia fue respondida y la nueva dificultad.
        """
        if self.pregunta_actual_index >= len(self.preguntas_actuales):
            return False, dificultad
        
        root = tk.Tk()
        root.title(f"Trivia - Nivel {self.current_level + 1}")
        root.geometry("500x300")
        
        pregunta_nodo = self.preguntas_actuales[self.pregunta_actual_index]
        info_pregunta = self.trivia.obtener_info_pregunta(pregunta_nodo)
        
        pregunta_label = tk.Label(
            root, 
            text=info_pregunta['pregunta'], 
            wraplength=400, 
            font=('Arial', 14)
        )
        pregunta_label.pack(pady=20)
        
        respuesta_seleccionada = tk.StringVar()
        
        opciones = info_pregunta['opciones'].copy()
        random.shuffle(opciones)
        
        def seleccionar_respuesta(respuesta):
            respuesta_seleccionada.set(respuesta)
            root.destroy()
        
        for opcion in opciones:
            boton = tk.Button(
                root, 
                text=opcion, 
                command=lambda o=opcion: seleccionar_respuesta(o)
            )
            boton.pack(pady=5)
        
        root.update_idletasks()
        width = root.winfo_width()
        height = root.winfo_height()
        x = (root.winfo_screenwidth() // 2) - (width // 2)
        y = (root.winfo_screenheight() // 2) - (height // 2)
        root.geometry(f'+{x}+{y}')
        
        root.mainloop()
        
        nueva_dificultad = dificultad

        if respuesta_seleccionada.get():
            es_correcta = respuesta_seleccionada.get() == info_pregunta['respuesta']
            self.trivia.actualizar_historial(pregunta_nodo, es_correcta)
            
            root = tk.Tk()
            root.withdraw()
            if es_correcta:
                messagebox.showinfo("Correcto", "¡Has acertado! Puedes continuar.")
                self.preguntas_correctas += 1
                self.total_score += 2
                nueva_dificultad = dificultad
            else:
                messagebox.showinfo("Incorrecto", f"La respuesta correcta era: {info_pregunta['respuesta']}")
                nueva_dificultad = dificultad + 1
            root.destroy()
            
            self.pregunta_actual_index += 1
            self.trivia_respondida = True
        
        return True, nueva_dificultad

    def handle_game_logic(self):
        """
        Maneja la lógica del juego, incluyendo la interacción con eventos y el cambio 
        de estado entre los diferentes modos de juego ("trivia", "playing", "victory", "game_over").
        
        Returns:
            bool: True si el juego sigue corriendo, False si ha terminado.
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
        
        if self.game_state == "trivia":
            if not self.trivia_respondida:
                resultado, self.dificultad_nivel = self.lanzar_trivia_tkinter(self.dificultad_nivel)

                if not resultado:
                    self.current_level += 1
                    
                    if self.current_level >= len(self.world_order):
                        self.game_state = "victory"
                        return True
                    
                    # Reiniciar preguntas para el nuevo nivel
                    self.trivia.iniciar_nueva_partida()
                    self.preguntas_actuales = self.trivia.seleccionar_preguntas_partida()
                    self.pregunta_actual_index = 0
                
                return True
            
            # Cambiar a estado de juego cuando se respondan las preguntas
            self.game_state = "playing"
            self.crear_nivel(self.world_order[self.current_level], self.dificultad_nivel)
            self.player.rect.x = WINDOW_WIDTH // 2
            self.player.rect.y = WINDOW_HEIGHT - PLAYER_SIZE - 10
            self.trivia_respondida = False
        
        if self.game_state == "playing":
            keys = pygame.key.get_pressed()
            dx = keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]
            dy = keys[pygame.K_DOWN] - keys[pygame.K_UP]
            self.player.move(dx, dy)

            for obj in self.moving_objects:
                obj.move()
                if self.check_collision(self.player.rect, obj.rect):
                    self.player.is_alive = False
                    self.game_state = "game_over"
                    return True

            if self.player.rect.top < 10:
                # Actualizar puntos por pasar nivel
                if self.dificultad_nivel > 1:
                    self.niveles_con_dificultad += 1
                    self.total_score += 1.5
                else:
                    self.niveles_sin_dificultad += 1
                    self.total_score += 1
                
                self.current_level += 1
                self.dificultad_nivel = 1
                self.trivia_respondida = False
                self.game_state = "trivia"
                
                if self.current_level >= len(self.world_order):
                    self.game_state = "victory"
                    return True
        
        return True

    def render_screen(self):
        """
        Dibuja la pantalla del juego, mostrando el estado actual del juego (ya sea 
        el nivel, el puntaje, los objetos en movimiento y el jugador).
        """
        if self.game_state == "playing":
            theme = WORLDS[self.world_order[self.current_level]]
            self.screen.fill(theme["background"])
            
            level_text = self.small_font.render(f"Mundo: {self.world_order[self.current_level]}", True, WHITE)
            score_text = self.small_font.render(f"Puntaje: {self.total_score}", True, WHITE)
            difficulty_text = self.small_font.render(f"Dificultad: {self.dificultad_nivel}", True, WHITE)
            
            self.screen.blit(level_text, (10, 10))
            self.screen.blit(score_text, (10, 30))
            self.screen.blit(difficulty_text, (10, 50))
            
            for obj in self.moving_objects:
                obj.draw(self.screen)
            
            self.player.draw(self.screen)
        
        pygame.display.flip()

    def mostrar_pantalla_victoria(self):
        """
        Muestra la pantalla de victoria con el puntaje total y un resumen de los puntos 
        obtenidos por respuestas correctas y por niveles completados.
        """
        self.screen.fill(GREEN)
        y_pos = WINDOW_HEIGHT // 4

        textos = [
            f"¡VICTORIA!",
            f"Preguntas correctas: {self.preguntas_correctas} de 5",
            f"Puntos por preguntas: {self.preguntas_correctas * 2}",
            f"Puntos por niveles sin dificultad: {self.niveles_sin_dificultad}",
            f"Puntos por niveles con dificultad: {self.niveles_con_dificultad * 1.5}",
            f"Puntaje total: {self.total_score}"
        ]

        for texto in textos:
            text_surface = self.font.render(texto, True, WHITE)
            text_rect = text_surface.get_rect(center=(WINDOW_WIDTH // 2, y_pos))
            self.screen.blit(text_surface, text_rect)
            y_pos += 50

        pygame.display.flip()
        pygame.time.wait(5000)  # Esperar 5 segundos antes de pedir guardar

    def guardar_partida(self):
        """
        Muestra un cuadro de diálogo para que el jugador ingrese el nombre de la partida 
        y guarda el puntaje final en el historial de partidas.
        """
        root = tk.Tk()
        root.withdraw()
        
        nombre_partida = simpledialog.askstring(
            "Guardar Partida", 
            "Ingresa el nombre de la partida (o presiona Enter para guardarlo automáticamente):"
        )
        
        # Registrar el puntaje final en el árbol trivia
        self.trivia.puntaje_actual = self.total_score
        self.trivia.registrar_partida(nombre_partida)
        root.destroy()

    def mostrar_menu_final(self):
        """
        Muestra el menú final donde el jugador puede ver el historial de partidas, 
        iniciar una nueva partida o salir del juego.
        
        Returns:
            str: La opción seleccionada por el jugador ("new_game" o salir del juego).
        """
        # Colores para los botones
        color_normal = (100, 100, 100)
        color_hover = (150, 150, 150)
        
        class Boton:
            def __init__(self, x, y, w, h, texto):
                self.rect = pygame.Rect(x, y, w, h)
                self.texto = texto
                self.hover = False
                
            def dibujar(self, screen, font):
                color = color_hover if self.hover else color_normal
                pygame.draw.rect(screen, color, self.rect, border_radius=10)
                pygame.draw.rect(screen, WHITE, self.rect, 2, border_radius=10)
                texto_surface = font.render(self.texto, True, WHITE)
                texto_rect = texto_surface.get_rect(center=self.rect.center)
                screen.blit(texto_surface, texto_rect)
        
        # Crear botones
        ancho_boton = 300
        alto_boton = 60
        x_centrado = WINDOW_WIDTH // 2 - ancho_boton // 2
        
        botones = [
            Boton(x_centrado, 200, ancho_boton, alto_boton, "Ver Historial de Partidas"),
            Boton(x_centrado, 300, ancho_boton, alto_boton, "Nueva Partida"),
            Boton(x_centrado, 400, ancho_boton, alto_boton, "Salir")
        ]
        
        while True:
            self.screen.fill((50, 50, 70))  # Fondo oscuro
            
            # Título
            titulo = self.large_font.render("Menú Principal", True, WHITE)
            titulo_rect = titulo.get_rect(center=(WINDOW_WIDTH // 2, 100))
            self.screen.blit(titulo, titulo_rect)
            
            # Actualizar estado hover de los botones
            mouse_pos = pygame.mouse.get_pos()
            for boton in botones:
                boton.hover = boton.rect.collidepoint(mouse_pos)
                boton.dibujar(self.screen, self.font)
            
            pygame.display.flip()
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                    
                if event.type == pygame.MOUSEBUTTONDOWN:
                    for i, boton in enumerate(botones):
                        if boton.rect.collidepoint(event.pos):
                            if i == 0:  # Ver Historial
                                return self.mostrar_historial_partidas()
                            elif i == 1:  # Nueva Partida
                                return "new_game"
                            elif i == 2:  # Salir
                                pygame.quit()
                                sys.exit()

    def check_collision(self, player_rect, object_rect):
        """
        Verifica si el jugador ha colisionado con un objeto en el nivel actual.
        
        Args:
            player_rect: Rectángulo que representa la posición del jugador.
            object_rect: Rectángulo que representa la posición de un objeto.
        """
        margin = 5
        player_rect = player_rect.inflate(-margin, -margin)
        object_rect = object_rect.inflate(-margin, -margin)
        return player_rect.colliderect(object_rect)

    def mostrar_pantalla_game_over(self):
        """
        Muestra la pantalla de Game Over con el puntaje total y un resumen de los puntos 
        obtenidos por respuestas correctas y por niveles completados.
        """
        background_image = pygame.image.load(r"bgmain\gameoverbackground.png")
        background_image = pygame.transform.scale(background_image, (WINDOW_WIDTH, WINDOW_HEIGHT))
        
        self.screen.blit(background_image, (0, 0))
        
        y_pos = WINDOW_HEIGHT // 4

        textos = [
            f"        ",
            f"Preguntas correctas: {self.preguntas_correctas} de 5",
            f"Puntos por preguntas: {self.preguntas_correctas * 2}",
            f"Puntos por niveles sin dificultad: {self.niveles_sin_dificultad}",
            f"Puntos por niveles con dificultad: {self.niveles_con_dificultad * 1.5}",
            f"Puntaje total: {self.total_score}"
        ]

        for texto in textos:
            text_surface = self.font.render(texto, True, BLACK)
            text_rect = text_surface.get_rect(center=(WINDOW_WIDTH // 2, y_pos))
            self.screen.blit(text_surface, text_rect)
            y_pos += 50

        pygame.display.flip()
        pygame.time.wait(5000)  # Esperar 5 segundos antes de pedir guardar


    def guardar_partida_game_over(self):
        """
        Muestra un cuadro de diálogo para guardar la partida cuando el jugador pierda el juego.
        """
        root = tk.Tk()
        root.withdraw()
        
        nombre_partida = simpledialog.askstring(
            "Guardar Partida", 
            "Ingresa el nombre de la partida (Game Over) (o presiona Enter para guardarlo automáticamente):"
        )
        
        # Registrar el puntaje final en el árbol trivia
        self.trivia.puntaje_actual = self.total_score
        if nombre_partida is None or nombre_partida.strip() == "":
            nombre_partida = f"Game Over - {self.total_score} pts"
        else:
            nombre_partida = f"{nombre_partida} (Game Over)"
            
        self.trivia.registrar_partida(nombre_partida)
        root.destroy()

    def run(self):
        """
        Inicia el bucle principal del juego, gestionando la lógica del juego y 
        las interacciones del jugador, incluyendo las transiciones entre los diferentes estados del juego.
        """
        while True:
            running = True
            while running:
                running = self.handle_game_logic()
                self.render_screen()
                self.clock.tick(60)

                if self.game_state == "victory":
                    self.mostrar_pantalla_victoria()
                    self.guardar_partida()
                    resultado = self.mostrar_menu_final()
                    if resultado == "new_game":
                        self.__init__()
                        running = True
                        continue
                    running = False

                if self.game_state == "game_over":
                    self.mostrar_pantalla_game_over()
                    self.guardar_partida_game_over()
                    resultado = self.mostrar_menu_final()
                    if resultado == "new_game":
                        self.__init__()
                        running = True
                        continue
                    running = False

if __name__ == "__main__":
    game = CrossyRoadTrivia()
    game.run()