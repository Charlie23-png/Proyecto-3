import pygame
import random
import sys
from Crossy import CrossyRoadTrivia, WORLDS, WINDOW_WIDTH, WINDOW_HEIGHT

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

class SimpleWorldSelector:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Selección de Mundo - Crossy Road Trivia")
        
        self.font_title = pygame.font.Font(None, 48)
        self.font_text = pygame.font.Font(None, 36)
        
        
        self.background_image = pygame.image.load(r"bgmain\worldsbackground.png")
        self.background_image = pygame.transform.scale(self.background_image, (WINDOW_WIDTH, WINDOW_HEIGHT)) 
        
        self.world_list = list(WORLDS.keys())

    def get_random_worlds(self, selected_world):
        remaining_worlds = self.world_list.copy()
        remaining_worlds.remove(selected_world)
        random.shuffle(remaining_worlds)
        return [selected_world] + remaining_worlds

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                    
                if event.type == pygame.KEYDOWN:
                    # Detectar teclas 1-5 para selección de mundo
                    if event.key in [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5]:
                        # Convertir la tecla a índice (1 -> 0, 2 -> 1, etc.)
                        index = event.key - pygame.K_1
                        if index < len(self.world_list):
                            selected_world = self.world_list[index]
                            # Crear nueva instancia del juego con el mundo seleccionado
                            game = CrossyRoadTrivia()
                            game.world_order = self.get_random_worlds(selected_world)
                            return game.run()
            
            # Dibujar la imagen de fondo
            self.screen.blit(self.background_image, (0, 0))
            
            pygame.display.flip()

def main():
    while True:
        selector = SimpleWorldSelector()
        selector.run()

if __name__ == "__main__":
    main()
