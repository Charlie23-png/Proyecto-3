import pygame
import random
from typing import Tuple
import threading
from Arbol import TriviaGUI, ArbolTrivia

# Initialize Pygame
pygame.init()

# Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
PLAYER_SIZE = 40
OBJECT_WIDTH = 60
OBJECT_HEIGHT = 40
MOVEMENT_SPEED = 5
OBJECT_SPEED = 3
BUTTON_WIDTH = 100
BUTTON_HEIGHT = 40
BUTTON_MARGIN = 10

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
BUTTON_COLOR = (70, 130, 180)  # Steel Blue
BUTTON_HOVER_COLOR = (100, 149, 237)  # Cornflower Blue

WORLDS = {
    "City of Stars": {
        "background": (50, 50, 70),
        "background_image": r"bgmain/JPG/FONDOCIUDAD.png",
        "objects": [
            {"type": "car", "image": r"bgmain/JPG/carroderecha.png"},
            {"type": "bus", "image": r"bgmain/JPG/carroiizq.png"},
        ],
    },
    "Cowboys": {
        "background": (139, 69, 19),
        "background_image": r"bgmain/JPG/FONDOTEXAS.png",
        "objects": [
            {"type": "rodadora", "image": r"bgmain/JPG/plantarodante.png"},
        ],
    },
    "Fairy Forest": {
        "background": (34, 139, 34),
        "background_image": r"bgmain/JPG/FONDOBOSQUE.png",
        "objects": [
            {"type": "pelota", "image": r"bgmain/JPG/pelotafutbol.png"},
        ],
    },
    "The end of the rawr": {
        "background": (169, 169, 169),
        "background_image": r"bgmain/JPG/FONDOESPACIO.png",
        "objects": [
            {"type": "asteroide", "image": r"bgmain/JPG/asteroide.png"},
        ],
    },
    "Santa Teresa Beach": {
        "background": (135, 206, 235),
        "background_image": r"bgmain/JPG/FONDOARENA.png",
        "objects": [
            {"type": "pelotaplaya", "image": r"bgmain/JPG/PELOTAPLAYA.png"},
        ],
    },
}

class Button:
    def __init__(self, x, y, width, height, text, font_size=24):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = BUTTON_COLOR
        self.hover_color = BUTTON_HOVER_COLOR
        self.font = pygame.font.Font(None, font_size)
        self.is_hovered = False

    def draw(self, screen):
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(screen, color, self.rect, border_radius=5)
        pygame.draw.rect(screen, BLACK, self.rect, 2, border_radius=5)  # Border
        
        text_surface = self.font.render(self.text, True, WHITE)
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.is_hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.is_hovered:
                return True
        return False

class Player:
    def __init__(self):
        # Cargar y escalar la imagen del jugador
        self.image = pygame.image.load(r"bgmain\conejin.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (PLAYER_SIZE, PLAYER_SIZE))
        
        # Ajustar la posición inicial del jugador para que aparezca más abajo
        self.rect = self.image.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT - PLAYER_SIZE - 5))
        self.score = 0
        self.is_alive = True

    def move(self, dx, dy):
        new_rect = self.rect.move(dx * MOVEMENT_SPEED, dy * MOVEMENT_SPEED)
        if 0 <= new_rect.x <= WINDOW_WIDTH - PLAYER_SIZE and 0 <= new_rect.y <= WINDOW_HEIGHT - PLAYER_SIZE:
            self.rect = new_rect

    def draw(self, screen):
        # Dibujar la imagen del jugador en su posición actual
        screen.blit(self.image, self.rect.topleft)


class MovingObject:
    def __init__(self, y_pos: int, x_pos: int, direction: int, object_type: str, image_path: str):
        self.direction = direction
        self.object_type = object_type
        self.speed = OBJECT_SPEED + random.uniform(-1, 1)

        # Cargar y redimensionar la imagen del objeto
        self.image = pygame.image.load(image_path).convert_alpha()
        self.image = pygame.transform.scale(self.image, (OBJECT_WIDTH, OBJECT_HEIGHT))

        # Crear el rectángulo de colisión basado en la imagen
        self.rect = self.image.get_rect(topleft=(x_pos, y_pos))

    def move(self):
        self.rect.x += self.direction * self.speed
        if self.direction > 0 and self.rect.left > WINDOW_WIDTH:
            self.rect.right = 0
        elif self.direction < 0 and self.rect.right < 0:
            self.rect.left = WINDOW_WIDTH

    def draw(self, screen):
        # Dibujar la imagen en la posición actual
        screen.blit(self.image, self.rect.topleft)




class Game:
    def __init__(self):
        self.can_move = False
        self.map_opened = False
        self.cont = 0  # Inicializar contador de respuestas correctas
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Crossy Road")
        self.clock = pygame.time.Clock()
        self.player = Player()
        self.current_level = 0
        self.world_order = []
        self.moving_objects = []
        self.game_state = "menu"
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        self.score = 0
        self.show_tutorial = True
        self.tutorial_timer = 180
        self.completed_game = False
        self.trivia_answered = False

        # Cargar la imagen de fondo para la pantalla de "Game Over"
        self.game_over_background = pygame.image.load(r'bgmain\gameoverbackground.png')
        self.game_over_background = pygame.transform.scale(self.game_over_background, (WINDOW_WIDTH, WINDOW_HEIGHT))

        # Cargar imágenes de fondo de cada mundo
        for world, data in WORLDS.items():
            if "background_image" in data:
                data["background_image_obj"] = pygame.image.load(data["background_image"]).convert()
                data["background_image_obj"] = pygame.transform.scale(data["background_image_obj"], (WINDOW_WIDTH, WINDOW_HEIGHT))

        self.trivia_button = Button(
            BUTTON_MARGIN, 
            WINDOW_HEIGHT - BUTTON_HEIGHT - BUTTON_MARGIN/2, 
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "Trivia"
        )
    
    

    def open_trivia_window(self):
        if not self.map_opened:
            self.map_opened = True

            def run_trivia():
                import tkinter as tk

                def on_trivia_complete():
                    # Incrementar el puntaje del juego con el valor de self.cont
                    self.score += trivia_game.cont  # Agrega el puntaje acumulado en la trivia
                    print(f"Nuevo puntaje total: {self.score}")
                    root.destroy()

                # Crear la ventana de trivia
                root = tk.Tk()
                trivia = ArbolTrivia()
                trivia_game = TriviaGUI(root, trivia)

                # Configurar evento de cierre
                root.protocol("WM_DELETE_WINDOW", on_trivia_complete)

                # Ejecutar el bucle principal
                root.mainloop()

            # Ejecutar la trivia en un hilo separado
            trivia_thread = threading.Thread(target=run_trivia, daemon=True)
            trivia_thread.start()


    def create_level(self, world_theme):
        self.moving_objects = []
        theme = WORLDS[world_theme]
        y_positions = [100, 200, 300, 400, 500]

        for i, obj_data in enumerate(theme["objects"]):
            direction = random.choice([1, -1])
            object_type = obj_data["type"]
            image_path = obj_data["image"]
            
            spacing = WINDOW_WIDTH // 4
            
            for j in range(3):
                if direction > 0:
                    x_pos = -OBJECT_WIDTH + (j * spacing)
                else:
                    x_pos = WINDOW_WIDTH + (j * spacing)
                
                self.moving_objects.append(
                    MovingObject(y_positions[i], x_pos, direction, object_type, image_path)
                )

        def check_collision(self, player_rect, object_rect):
            margin = 10  # Reducir el tamaño del rectángulo de colisión
            player_rect = player_rect.inflate(-margin, -margin)
            object_rect = object_rect.inflate(-margin, -margin)
            return player_rect.colliderect(object_rect)

        
        def pause_with_green_frame(self):
            self.screen.fill(GREEN)
            pause_text = self.font.render("¡Has llegado al quinto nivel!", True, WHITE)
            continue_text = self.small_font.render("Presiona cualquier tecla para continuar...", True, WHITE)

            self.screen.blit(pause_text, (WINDOW_WIDTH // 2 - pause_text.get_width() // 2, WINDOW_HEIGHT // 2 - 50))
            self.screen.blit(continue_text, (WINDOW_WIDTH // 2 - continue_text.get_width() // 2, WINDOW_HEIGHT // 2 + 50))

            pygame.display.flip()

            paused = True
            while paused:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.display.quit()
                        return
                    if event.type == pygame.KEYDOWN:  # Despausar al presionar cualquier tecla
                        paused = False


    
    def handle_menu(self):
        background_image = pygame.image.load(r'bgmain\worldsbackground.png')
        background_image = pygame.transform.scale(background_image, (WINDOW_WIDTH, WINDOW_HEIGHT))
        self.screen.blit(background_image, (0, 0))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                if pygame.K_1 <= event.key <= pygame.K_5:
                    selected_world = list(WORLDS.keys())[event.key - pygame.K_1]
                    remaining_worlds = [w for w in WORLDS.keys() if w != selected_world]
                    random.shuffle(remaining_worlds)
                    self.world_order = [selected_world] + remaining_worlds
                    self.current_level = 0
                    self.create_level(self.world_order[0])
                    self.game_state = "playing"
                    self.player = Player()
                    self.show_tutorial = True
                    self.tutorial_timer = 180
                    self.score = 0

        return True

    def handle_game_over(self):
        self.screen.blit(self.game_over_background, (0, 0))
        game_over_text = self.font.render("SPACE TO CONTINUE", True, BLACK)
        score_text = self.font.render(f"SCORE: {self.score}", True, BLACK)
        restart_text = self.font.render("ESC TO EXIT", True, BLACK)
        
        self.screen.blit(game_over_text, (WINDOW_WIDTH//2 - game_over_text.get_width()//2, 300))
        self.screen.blit(score_text, (WINDOW_WIDTH//2 - score_text.get_width()//2, 220))
        self.screen.blit(restart_text, (WINDOW_WIDTH//2 - restart_text.get_width()//2, WINDOW_HEIGHT//2 + 80))
        
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.__init__()
                    return True
                elif event.key == pygame.K_ESCAPE:
                    return False
        return True

    def draw_tutorial(self):
        if self.tutorial_timer > 0:
            tutorial_text = self.small_font.render("Usa las flechas para moverte. ¡Evita los obstáculos!", True, WHITE)
            tutorial_rect = tutorial_text.get_rect(center=(WINDOW_WIDTH//2, 50))
            self.screen.blit(tutorial_text, tutorial_rect)
            self.tutorial_timer -= 1

    
    def handle_playing(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            # Manejo del botón de trivia
            if self.trivia_button.handle_event(event):
                print(f"Trivia button clicked for {self.world_order[self.current_level]}")
                self.open_trivia_window()
                self.can_move = True  # Habilita el movimiento después de presionar el botón

        # Permitir movimiento solo si se ha habilitado
        if self.can_move:
            keys = pygame.key.get_pressed()
            dx = keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]
            dy = keys[pygame.K_DOWN] - keys[pygame.K_UP]
            self.player.move(dx, dy)

        for obj in self.moving_objects:
            obj.move()
            if self.check_collision(self.player.rect, obj.rect):
                self.player.is_alive = False
                self.game_state = "game_over"
                return True

        # Comprobación de llegada al límite superior y avance de nivel
        if self.player.rect.top < 10:
            self.score += 1
            self.current_level += 1

            if self.current_level == len(self.world_order):  # Nivel 5 alcanzado
                self.pause_with_green_frame()
                return False  # Opcional: salir del juego tras el frame verde

            self.create_level(self.world_order[self.current_level])
            self.player.rect.x = WINDOW_WIDTH // 2
            self.player.rect.y = WINDOW_HEIGHT - PLAYER_SIZE - 10
            self.can_move = False  # Desactiva el movimiento al iniciar un nuevo nivel

        theme = WORLDS[self.world_order[self.current_level]]
        background_image = theme.get("background_image_obj")

        if background_image:
            self.screen.blit(background_image, (0, 0))
        else:
            self.screen.fill(theme["background"])

        # Mostrar nivel y puntaje
        level_text = self.small_font.render(f"Mundo: {self.world_order[self.current_level]}", True, WHITE)
        score_text = self.small_font.render(f"Puntaje: {self.score}", True, WHITE)

        self.screen.blit(level_text, (10, 10))
        self.screen.blit(score_text, (10, 30))

        # Dibujar objetos en movimiento, jugador y botón de trivia
        for obj in self.moving_objects:
            obj.draw(self.screen)

        self.player.draw(self.screen)
        self.trivia_button.draw(self.screen)

        # Mostrar tutorial si está activo
        if self.show_tutorial:
            self.draw_tutorial()

        pygame.display.flip()
        self.clock.tick(60)
        return True


    def run(self):
        running = True
        while running:
            if self.game_state == "menu":
                running = self.handle_menu()
            elif self.game_state == "playing":
                running = self.handle_playing()
            elif self.game_state == "game_over":
                running = self.handle_game_over()




if __name__ == "__main__":
    game = Game()
    game.run()
